package com.example.int221integratedkk1_backend;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication

public class Int221IntegratedKk1BackendApplication {

    public static void main(String[] args) {
        SpringApplication.run(Int221IntegratedKk1BackendApplication.class, args);
    }

}
