package com.example.int221integratedkk1_backend;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class Int221IntegratedKk1BackendApplicationTests {

    @Test
    void contextLoads() {
    }

}
